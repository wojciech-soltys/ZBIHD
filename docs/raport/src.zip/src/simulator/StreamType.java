package simulator;

public enum StreamType {
	LIST, CSV, CSV_LABELS, DATABASE
}
